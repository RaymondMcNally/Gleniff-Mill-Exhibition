"""Build guide PDF for the Gleniff heliodon: drawing, parts, assembly and the sun setting table."""
import json, math, sys
from reportlab.lib.pagesizes import A3, landscape
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor, black, white

OUT = sys.argv[1]
S = json.load(open(f'{OUT}/heliodon_parts.json'))
T = json.load(open('suntable.json'))
P = S['params']
pdfmetrics.registerFont(TTFont('Sans', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('SansB', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('Mono', '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'))
INK, MUT, RULE, RED, GOLD, GREEN = HexColor('#1d2120'), HexColor('#5f6663'), HexColor('#c9ccc7'), HexColor('#c0432a'), HexColor('#d99a1e'), HexColor('#4f7a45')
W, H = landscape(A3)
c = canvas.Canvas(f'{OUT}/Gleniff_heliodon_build_guide.pdf', pagesize=landscape(A3))
c.setTitle('Gleniff heliodon: build guide'); c.setAuthor('R McNally, ATU Sligo')


def head(title, sub, n):
    c.setFillColor(INK); c.setFont('SansB', 20); c.drawString(18 * mm, H - 20 * mm, title)
    c.setFont('Sans', 10); c.setFillColor(MUT); c.drawString(18 * mm, H - 27 * mm, sub)
    c.setStrokeColor(RULE); c.setLineWidth(0.6); c.line(18 * mm, H - 31 * mm, W - 18 * mm, H - 31 * mm)
    c.setFont('Sans', 8); c.drawString(18 * mm, 10 * mm, 'ATU Sligo · Department of Architecture · ARCT06004 · Gleniff Barytes Mill')
    c.drawRightString(W - 18 * mm, 10 * mm, f'Sheet {n} of 3')


def para(x, y, text, size=9.5, width=120 * mm, lead=1.38, font='Sans', color=INK):
    c.setFont(font, size); c.setFillColor(color)
    for line in text.split('\n'):
        words, cur = line.split(' '), ''
        for w_ in words:
            trial = (cur + ' ' + w_).strip()
            if pdfmetrics.stringWidth(trial, font, size) > width:
                c.drawString(x, y, cur); y -= size * lead; cur = w_
            else:
                cur = trial
        c.drawString(x, y, cur); y -= size * lead
    return y


# ================================================================== sheet 1: elevation and plan
head('Gleniff heliodon', 'A bench sun simulator for 250 mm site models at 54.4° N. Laser-cut 6 mm plywood, one LED.', 1)
sc = 0.105 * mm             # 1 mm real -> drawing (≈ 1:10)
ox, oy = 62 * mm, 100 * mm   # arc centre on the sheet (bench is H below)
X = lambda x: ox + x * sc
Y = lambda y: oy + y * sc
Ri, Ro, Hh, yb = P['Ri'], P['Ro'], P['H'], S['yb']
# bench
c.setStrokeColor(INK); c.setLineWidth(1.2); c.line(X(-420), Y(-Hh), X(1750), Y(-Hh))
c.setFont('Sans', 8); c.setFillColor(MUT); c.drawString(X(1650), Y(-Hh) - 10, 'bench')
# turntable + model block
c.setFillColor(HexColor('#e8e2d4')); c.setStrokeColor(INK); c.setLineWidth(0.6)
Bh, Tb, Rr, Mh = P['base'] / 2, P['tab'], P['ring'] / 2, P['model'] / 2
c.rect(X(-Bh), Y(-Hh), (2 * Bh + Tb) * sc, 6 * sc, fill=1); c.rect(X(-150), Y(-Hh + 6), 300 * sc, 8 * sc, fill=0)
c.rect(X(-P['disc'] / 2), Y(-Hh + 14), P['disc'] * sc, 6 * sc, fill=1)
c.setFillColor(HexColor('#d9c39c')); c.rect(X(-Rr), Y(-Hh + 20), 2 * Rr * sc, 6 * sc, fill=1)
c.setFillColor(HexColor('#c0432a')); c.rect(X(Rr + 2), Y(-Hh + 6), 50 * sc, 18 * sc, fill=1, stroke=0)
c.setFillColor(HexColor('#f4f1ea')); c.rect(X(-Mh), Y(-Hh + 26), 2 * Mh * sc, (Hh - 26) * sc, fill=1)
c.setFillColor(HexColor('#d8d3c8'))
p = c.beginPath(); p.moveTo(X(-Mh), Y(0)); p.lineTo(X(-50), Y(45)); p.lineTo(X(25), Y(20)); p.lineTo(X(Mh), Y(60)); p.lineTo(X(Mh), Y(0)); p.close()
c.drawPath(p, fill=1, stroke=1)
c.setFillColor(INK); c.setFont('Sans', 7.5); c.drawCentredString(X(0), Y(-Hh) - 10, f'turntable with {P["ring"]:.0f} mm scale ring and a {P["model"]:.0f} mm model')
c.setFillColor(HexColor('#c0432a')); c.drawString(X(Rr + 60), Y(-Hh + 12), 'index T5')
# strut
st = S['strut']; Pa, F = st['Pa'], st['foot']
ux, uy = F[0] - Pa[0], F[1] - Pa[1]; L = math.hypot(ux, uy); ux, uy = ux / L, uy / L
top = (Pa[0] - 40 * ux, Pa[1] - 40 * uy); nx, ny = -uy, ux
c.setFillColor(HexColor('#cbbf9f')); c.setStrokeColor(INK); c.setLineWidth(0.6)
p = c.beginPath()
for i, (s_, w_) in enumerate(((0, -25), (L + 40, -25), (L + 40, 25), (0, 25))):
    x, y = top[0] + s_ * ux + w_ * nx, top[1] + s_ * uy + w_ * ny; (p.moveTo if i == 0 else p.lineTo)(X(x), Y(max(y, -Hh)))
p.close(); c.drawPath(p, fill=1, stroke=1)
c.setFillColor(INK); c.circle(X(Pa[0]), Y(Pa[1]), 1.4, fill=1); c.circle(X(st['Pb'][0]), Y(st['Pb'][1]), 1.4, fill=1)
# arc band
def arcpath(r0, r1, a0, a1):
    pa = c.beginPath(); n = 120
    for k in range(n + 1):
        a = math.radians(a0 + (a1 - a0) * k / n); x, y = X(r1 * math.cos(a)), Y(r1 * math.sin(a))
        (pa.moveTo if k == 0 else pa.lineTo)(x, y)
    for k in range(n, -1, -1):
        a = math.radians(a0 + (a1 - a0) * k / n); pa.lineTo(X(r0 * math.cos(a)), Y(r0 * math.sin(a)))
    pa.close(); return pa
a_bot = math.degrees(math.asin(yb / Ro))
c.setFillColor(HexColor('#e6d6b8')); c.setStrokeColor(INK); c.setLineWidth(0.8)
c.drawPath(arcpath(Ri, Ro, a_bot, P['a_hi']), fill=1, stroke=1)
c.setStrokeColor(MUT); c.setDash(3, 2); c.setLineWidth(0.4)
c.drawPath(arcpath(S['Rm'] - P['slot'] / 2, S['Rm'] + P['slot'] / 2, 0, P['a_hi']), fill=0, stroke=1); c.setDash()
# scale ticks every 10°
c.setFont('Sans', 7); c.setFillColor(INK)
for a in range(0, 61, 10):
    ar = math.radians(a); c.setStrokeColor(INK); c.setLineWidth(0.5)
    c.line(X((Ro + 4) * math.cos(ar)), Y((Ro + 4) * math.sin(ar)), X((Ro + 40) * math.cos(ar)), Y((Ro + 40) * math.sin(ar)))
    c.drawCentredString(X((Ro + 85) * math.cos(ar)), Y((Ro + 85) * math.sin(ar)) - 3, f'{a}°')
# foot plates
c.setFillColor(HexColor('#cbbf9f')); c.rect(X(1100), Y(-Hh), 360 * sc, 6 * sc, fill=1); c.rect(X(1500), Y(-Hh), 200 * sc, 6 * sc, fill=1)
# LED + rays at a winter and summer noon
for alt, col, lab in ((12.2, HexColor('#4a6fa5'), '21 Dec noon 12°'), (36.0, GOLD, 'Equinox noon 36°'), (59.0, RED, '21 Jun noon 59°')):
    ar = math.radians(alt); lx, ly = P['led_r'] * math.cos(ar), P['led_r'] * math.sin(ar)
    c.setStrokeColor(col); c.setLineWidth(0.7); c.setDash(4, 2); c.line(X(lx), Y(ly), X(0), Y(0)); c.setDash()
    c.setFillColor(col); c.circle(X(lx), Y(ly), 4, fill=1, stroke=0)
    c.setFont('SansB', 7.5); c.drawString(X(lx) - 70 if alt > 50 else X(lx) - 78, Y(ly) + 6, lab)
# key dimensions
c.setStrokeColor(MUT); c.setLineWidth(0.4); c.setFillColor(MUT); c.setFont('Sans', 7.5)
c.line(X(0), Y(-Hh - 70), X(Ri), Y(-Hh - 70)); c.drawCentredString(X(Ri / 2), Y(-Hh - 70) - 10, f'model centre to the arc inner edge {Ri:.0f}')
c.line(X(0), Y(0), X(0), Y(-Hh - 75)); c.line(X(Ri), Y(-Hh), X(Ri), Y(-Hh - 75))
c.drawString(X(-420), Y(130), f'Arc centre {Hh:.0f} mm above the bench')
c.drawString(X(-420), Y(130) - 10, '= top of the model base')
c.setFillColor(INK); c.setFont('SansB', 10); c.drawString(18 * mm, H - 42 * mm, 'Side elevation, about 1:10 (strut behind the rib)')
c.setFont('Sans', 8); c.setFillColor(MUT)
c.drawString(18 * mm, H - 48 * mm, f'LED {P["led_r"]:.0f} mm from the model centre. Arc band {Ri:.0f}–{Ro:.0f} mm, 3 layers of 6 mm ply (18 mm), scale 0°–64°.')

# plan of the setting-out (top right). Plan x = outward to the arc, z = sideways (beam plane z = 0)
px, py = 232 * mm, 222 * mm; sp = 0.085 * mm
PX = lambda x: px + x * sp
PZ = lambda z: py + z * sp * 2.2          # sideways stretched ×2.2 so the offsets read
c.setFillColor(INK); c.setFont('SansB', 10); c.drawString(px - 20 * mm, H - 42 * mm, 'Plan: lining up the beam plane (sideways ×2.2)')
c.setStrokeColor(INK); c.setLineWidth(0.6); c.setFillColor(HexColor('#f4f1ea'))
c.ellipse(PX(-P['ring'] / 2), PZ(-P['ring'] / 4.4), PX(P['ring'] / 2), PZ(P['ring'] / 4.4), fill=1)
c.setDash(2, 2); c.rect(PX(-P['model'] / 2), PZ(-P['model'] / 4.4), P['model'] * sp, P['model'] * sp, fill=0); c.setDash()
c.setFillColor(RED); c.circle(PX(P['ring'] / 2 + 6), PZ(0), 2, fill=1, stroke=0); c.setFillColor(HexColor('#f4f1ea'))
lz = P['led_z']
c.setFillColor(HexColor('#e6d6b8')); c.rect(PX(Ro * math.cos(math.radians(P['a_hi']))), PZ(-lz - 18), (Ro - Ro * math.cos(math.radians(P['a_hi']))) * sp, 18 * sp * 2.2, fill=1)
c.setFillColor(HexColor('#cbbf9f')); c.rect(PX(st['Pa'][0] - 30), PZ(-lz - 36), (1600 - st['Pa'][0] + 30) * sp, 18 * sp * 2.2, fill=1)
c.setFillColor(HexColor('#d8cfbb')); c.rect(PX(P['led_r'] - 5), PZ(-lz), 20 * sp, (lz + 30) * sp * 2.2, fill=1)
c.setStrokeColor(RED); c.setDash(4, 2); c.line(PX(-230), PZ(0), PX(1700), PZ(0)); c.setDash()
c.setFillColor(GOLD); c.circle(PX(P['led_r']), PZ(0), 2.6, fill=1, stroke=0)
c.setFillColor(RED); c.setFont('Sans', 7.5); c.drawString(PX(250), PZ(0) + 4, 'beam plane through the LED and the turntable centre')
c.setFillColor(INK); c.setFont('Sans', 7.5)
c.drawRightString(PX(505), PZ(-lz - 12), 'rib, 18 mm, seen from above'); c.drawString(PX(1100), PZ(-lz - 36) - 10, 'strut, behind the rib')
c.drawString(PX(P['led_r']) + 8, PZ(14), 'LED on carriage K1 + K2')
c.drawCentredString(PX(0), PZ(-P['ring'] / 4.4) - 10, 'scale ring, model dashed')
c.setStrokeColor(MUT); c.setLineWidth(0.4); c.line(PX(450), PZ(0), PX(450), PZ(-lz))
c.setFillColor(MUT); c.drawString(PX(450) + 3, PZ(-lz / 2) - 3, f'{lz:.0f} mm from the rib front face (gauge G1)')
# how it works + accuracy
y = para(18 * mm, 60 * mm, 'How it works', 11, font='SansB')
y = para(18 * mm, y - 2, 'The model never tilts. Turn the turntable until the sun’s bearing sits at the index mark, then slide the LED along the arc to the sun’s height. Both numbers are on sheet 3, or read Sun height now and Sun bearing off the Sun & climate page for any date and time. The bearing scale is on a 470 mm ring, outside the corners of a 250 mm model, so every number stays readable. At 1:200 a 5 mm pin is a 1 m post: check its shadow against Shadow of a 1 m post on the page.', 9, width=150 * mm)
y = para(190 * mm, 60 * mm, 'What it gets right, and what it doesn’t', 11, font='SansB')
para(190 * mm, y - 2, f'The LED is {P["led_r"] / 1000:.1f} m away, so its rays spread a little: across a {P["model"]:.0f} mm model, shadows at the edges point about {math.degrees(math.atan(P["model"] / 2 / P["led_r"])):.0f}° off the true direction ({math.degrees(math.atan(P["model"] / 2 ** 0.5 / P["led_r"])):.0f}° at the corners) and are a little long. The centre is exact. A bigger model needs the projector instead. The arc reaches 64°; the highest sun at Gleniff is 59° (21 June). The carriage can’t go below about 1°.', 9, width=150 * mm)
para(355 * mm, 60 * mm, 'LED', 11, font='SansB')
para(355 * mm, 60 * mm - 15, 'A 20–30 W COB LED, 4000–5000 K, with a 30–45° reflector or lens and a heatsink. Run the cable along the back of the rib. Dim the room for crisp shadows.', 9, width=48 * mm)
c.showPage()

# ================================================================== sheet 2: parts and assembly
head('Parts and assembly', f'{len(S["parts"])} parts on {S["sheets"]} sheets of {P["sheet"][0]:.0f} × {P["sheet"][1]:.0f} mm, 6 mm plywood. Red cut, blue score, black engrave.', 2)
cols = [(18, 'Part'), (34, 'Qty'), (44, 'Size mm'), (68, 'Sheet'), (82, 'What it is')]
y = H - 42 * mm
c.setFont('SansB', 8.5); c.setFillColor(INK)
for x, t_ in cols: c.drawString(x * mm, y, t_)
y -= 4 * mm; c.setStrokeColor(RULE); c.line(18 * mm, y + 2.5 * mm, 200 * mm, y + 2.5 * mm)
c.setFont('Sans', 7.6)
for p_ in S['parts']:
    vals = [p_['name'], str(p_['qty']), f'{p_["size"][0]} × {p_["size"][1]}', str(p_['sheet']), (p_['note'] if len(p_['note']) <= 84 else p_['note'][:82].rsplit(' ', 1)[0] + ' …')]
    for (x, _), v in zip(cols, vals): c.drawString(x * mm, y, v)
    y -= 4.15 * mm
y = para(215 * mm, H - 42 * mm, 'Also needed', 11, font='SansB')
y = para(215 * mm, y - 2, '• 300 mm (12 in) lazy-susan bearing, with screws\n• 6 mm dowel rod, about 1.5 m, cut to 18 mm lengths\n• 2 × M5 × 30 bolts, washers and wing nuts (carriage)\n• 2 × M5 × 50 countersunk bolts and nuts (strut)\n• 4 steel angle brackets and short wood screws (feet)\n• PVA wood glue, clamps, 2 G-clamps for the bench\n• COB LED, heatsink, lens, driver or power supply', 9, width=180 * mm)
y = para(215 * mm, y - 8, 'Assembly', 11, font='SansB')
steps = [
    'Glue the arc in three layers. Lay the back layer C1–C4 flat, joints butted. Glue the middle strips BI1–BI5 and BO1–BO5 on top, leaving the 11 mm channel open; their joints fall halfway along the C pieces. Then glue the front strips AI1–AI4 and AO1–AO4, scale outwards, leaving the 5.5 mm slot. Push dowels through every hole as you go to keep the layers lined up. Weight it flat overnight.',
    'Countersink the two strut holes on the front (they sit under the carriage’s path), bolt the strut layers SA, SB, SC together with glue, then bolt the strut to the back of the rib.',
    'Stand the rib on F1 between the scored lines and fix it with two angle brackets on the back face. Fix the strut foot to F2 the same way. Clamp both plates to the bench.',
    'Carriage: slide two M5 bolt heads (or K3 plates) into the channel from the top of the arc. Push K2’s tabs into K1’s slots and glue. Fit K1 over the bolts with washers and wing nuts. Mount the LED in K2 and aim it along the arc’s radius.',
    'Turntable: glue T3 in the middle of T1, then the ring halves T4A and T4B around it, numbers up, N over the MODEL NORTH arrow. Glue T5, T5 and T5T into the outline on T2’s tab. Screw the lazy susan between T2 and T1, centred. Stand it with the tab towards the arc, its centre on the beam plane (G1 gauge from the rib front face) and the inner-edge distance from the arc.',
    'Check it: set the carriage to 0° and sight along the LED. It should look straight at the turntable centre. Pack F1 or the turntable until the arc centre is level with the top of the model base.',
]
for i, s_ in enumerate(steps, 1):
    c.setFont('SansB', 9); c.setFillColor(RED); c.drawString(215 * mm, y, str(i))
    y = para(222 * mm, y, s_, 8.8, width=172 * mm) - 3
c.showPage()

# ================================================================== sheet 3: setting table
head('Setting table for Gleniff', 'Sun height (altitude) and bearing for each hour, Irish clock time (summer time included). Set the carriage to the height and the turntable to the bearing.', 3)
hours = list(range(6, 22))
x0, y0, rh = 18 * mm, H - 46 * mm, 12.3 * mm
cw = (W - 2 * x0 - 26 * mm - 30 * mm) / len(hours)
MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
c.setFont('SansB', 8.5); c.setFillColor(INK); c.drawString(x0, y0, 'Date')
for k, h_ in enumerate(hours): c.drawCentredString(x0 + 26 * mm + k * cw + cw / 2, y0, f'{h_:02d}:00')
c.drawString(x0 + 26 * mm + len(hours) * cw + 2 * mm, y0, 'Highest')
y = y0 - 4 * mm
for i, r in enumerate(T):
    if i % 2 == 0:
        c.setFillColor(HexColor('#f2efe8')); c.rect(x0 - 1 * mm, y - rh + 3.2 * mm, W - 2 * x0 + 2 * mm, rh, fill=1, stroke=0)
    special = {(10, 5): 'site visit', (11, 2): 'submission'}.get((r['m'], r['d']), '')
    c.setFillColor(INK); c.setFont('SansB', 9); c.drawString(x0, y - 2 * mm, f'{r["d"]} {MON[r["m"] - 1]}')
    if special: c.setFont('Sans', 7); c.setFillColor(RED); c.drawString(x0, y - 6 * mm, special)
    for k, h_ in enumerate(hours):
        v = r['hrs'].get(str(h_)); cx = x0 + 26 * mm + k * cw + cw / 2
        if v:
            c.setFillColor(INK); c.setFont('Mono', 8.6); c.drawCentredString(cx, y - 1.6 * mm, f'{v[0]:.0f}°')
            c.setFillColor(MUT); c.setFont('Mono', 7.6); c.drawCentredString(cx, y - 5.6 * mm, f'{v[1]:.0f}°')
        else:
            c.setFillColor(RULE); c.setFont('Mono', 8); c.drawCentredString(cx, y - 3.5 * mm, '·')
    nh = int(r['noon']); nm = round((r['noon'] - nh) * 60)
    c.setFillColor(INK); c.setFont('Mono', 8.6); c.drawString(x0 + 26 * mm + len(hours) * cw + 2 * mm, y - 1.6 * mm, f'{r["noonAlt"]:.0f}° {nh:02d}:{nm:02d}')
    c.setFillColor(MUT); c.setFont('Mono', 7.6); c.drawString(x0 + 26 * mm + len(hours) * cw + 2 * mm, y - 5.6 * mm, f'{r["noonAz"]:.0f}°')
    y -= rh
para(x0, y - 4 * mm, 'Top number: height above the horizon, for the arc. Bottom (grey): bearing clockwise from north, for the turntable. A dot means the sun is down. Figures are from the same calculation as the Sun & climate page, at the mill, 54.40° N 8.40° W, for 2026; other years differ by a fraction of a degree. The mountains outside the survey can hide a low sun: the heliodon, like the model, doesn’t know they’re there.', 8.5, width=W - 2 * x0)
c.showPage(); c.save()
print('ok')
