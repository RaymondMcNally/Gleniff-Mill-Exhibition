"""Gleniff heliodon: laser-cut parts for a bench sun simulator at 54.4° N.

Mechanism (altitude arc + azimuth turntable):
  * The model sits on a turntable. Turn it until the sun's bearing sits at the index mark.
  * A fixed vertical arc, centred on the model, carries an LED carriage. Slide it to the sun's altitude.
  The light then hits the model from the right direction for any date and time.

Frame for arc parts: origin at the arc centre (the top of the model's base, over the turntable centre),
x outward towards the arc, y up. Parts are drawn as seen from the FRONT (the carriage side).
All sizes in mm. Run: python3 make_heliodon.py outdir
"""
import json, math, sys, os
from shapely.geometry import Polygon, Point, box, LineString
from shapely.ops import unary_union
from shapely import affinity
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties
import ezdxf

OUT = sys.argv[1] if len(sys.argv) > 1 else 'out'
os.makedirs(OUT, exist_ok=True)

# ------------------------------------------------------------------ parameters
P = dict(
    t=6.0,            # board thickness (plywood)
    Ri=1160.0,        # arc inner radius
    Ro=1260.0,        # arc outer radius
    slot=5.5,         # front-layer slot (M5 bolt shank)
    chan=11.0,        # middle-layer channel (M5 bolt head)
    H=46.0,           # height of the arc centre above the bench = top of the model's base (26 mm turntable + 20 mm model base)
    a_lo=-2.0, a_hi=66.0,
    dowel=6.0, r_dow_in=1183.0, r_dow_out=1221.0,
    sheet=(600.0, 400.0), margin=6.0, gap=4.0,
    disc=360.0, base=380.0, tab=110.0, centre=300.0, ring=470.0, model=250.0,
    led_r=1100.0, led_z=46.0,   # LED radius from the centre, and its offset in front of the rib
)
t, Ri, Ro = P['t'], P['Ri'], P['Ro']
Rm = (Ri + Ro) / 2
yb = -(P['H'] - t)              # rib bottom (it stands on a 6 mm foot plate)

FONT = FontProperties(family='DejaVu Sans', weight='bold')


def ring_sector(r0, r1, a0, a1, step=0.25):
    n = max(2, int(abs(a1 - a0) / step) + 1)
    A = [a0 + (a1 - a0) * k / (n - 1) for k in range(n)]
    pts = [(r1 * math.cos(math.radians(a)), r1 * math.sin(math.radians(a))) for a in A]
    pts += [(r0 * math.cos(math.radians(a)), r0 * math.sin(math.radians(a))) for a in reversed(A)]
    return Polygon(pts)


def circle(x, y, d, n=48):
    return Point(x, y).buffer(d / 2, resolution=n // 4)


def text_polys(s, x, y, h, rot=0.0, anchor='c'):
    """Text outlines as shapely polygons, centred at (x, y), height h, rotated rot degrees."""
    tp = TextPath((0, 0), s, size=h * 1.37, prop=FONT)
    polys = []
    for poly in tp.to_polygons():
        if len(poly) >= 3:
            polys.append(Polygon(poly))
    if not polys:
        return []
    # even-odd: outer contours minus holes
    polys.sort(key=lambda p: -p.area)
    shapes = []
    for p in polys:
        p = p.buffer(0)
        for i, s2 in enumerate(shapes):
            if s2.contains(p):
                shapes[i] = s2.difference(p)
                break
        else:
            shapes.append(p)
    g = unary_union(shapes)
    minx, miny, maxx, maxy = g.bounds
    cx = (minx + maxx) / 2 if anchor == 'c' else minx
    g = affinity.translate(g, -cx, -(miny + maxy) / 2)
    g = affinity.rotate(g, rot, origin=(0, 0))
    g = affinity.translate(g, x, y)
    return [g]


class Part:
    def __init__(self, name, cut, score=None, engrave=None, qty=1, note=''):
        self.name, self.cut, self.qty, self.note = name, cut, qty, note
        self.score = score or []      # LineStrings
        self.engrave = engrave or []  # Polygons (filled)


def splits(a0, a1, offset_first):
    """Piece boundaries: first piece `offset_first` long, then 17° pieces."""
    b, a = [a0], a0 + offset_first
    while a < a1 - 1e-6:
        b.append(a); a += 17.0
    b.append(a1)
    return b


L1 = splits(P['a_lo'], P['a_hi'], 17.0)      # -2, 15, 32, 49, 66
L2 = splits(P['a_lo'], P['a_hi'], 8.5)       # -2, 6.5, 23.5, 40.5, 57.5, 66
DOWELS = [P['a_lo'] + 2.125 + 4.25 * k for k in range(16)]
STRUT_BOLTS = []                            # filled in below (rib-frame points)

bench_clip = box(-5000, yb, 5000, 5000)


def holes_for(poly):
    hs = []
    for a in DOWELS:
        for r in (P['r_dow_in'], P['r_dow_out']):
            if r == P['r_dow_in'] and any(math.hypot(r * math.cos(math.radians(a)) - bx, r * math.sin(math.radians(a)) - by) < 25 for bx, by in STRUT_BOLTS):
                continue                                   # keep clear of the strut bolts
            c = circle(r * math.cos(math.radians(a)), r * math.sin(math.radians(a)), P['dowel'])
            if poly.buffer(-1).contains(c):
                hs.append(c)
    for (x, y) in STRUT_BOLTS:
        c = circle(x, y, 5.5)
        if poly.buffer(-1).contains(c):
            hs.append(c)
    return hs


def scale_marks(poly):
    """Altitude scale on the front of the outer strip: ticks every 1°, labels every 10°."""
    score, eng = [], []
    for a in range(0, 65):
        L = 14 if a % 10 == 0 else 9 if a % 5 == 0 else 5
        r1, r0 = Ro - 1.5, Ro - 1.5 - L
        ar = math.radians(a)
        ln = LineString([(r0 * math.cos(ar), r0 * math.sin(ar)), (r1 * math.cos(ar), r1 * math.sin(ar))])
        if poly.contains(ln):
            score.append(ln)
        if a % 10 == 0:
            rr = 1233.0
            g = text_polys(f'{a}°', rr * math.cos(ar), rr * math.sin(ar), 6.5, rot=a - 90)
            for gg in g:
                if poly.contains(gg):
                    eng.append(gg)
    return score, eng


parts = []
# strut geometry (rib frame): bolt points on the inner strip, line down to the rear foot
Pa = (1183 * math.cos(math.radians(45)), 1183 * math.sin(math.radians(45)))
F = (1600.0, -P['H'])
d = (F[0] - Pa[0], F[1] - Pa[1]); dl = math.hypot(*d); u = (d[0] / dl, d[1] / dl)
Pb = (Pa[0] + 60 * u[0], Pa[1] + 60 * u[1])
STRUT_BOLTS[:] = [Pa, Pb]


def band_layer(tag, r0, r1, bounds, label_scale=False, solid_note=''):
    for k in range(len(bounds) - 1):
        a0, a1 = bounds[k], bounds[k + 1]
        poly = ring_sector(r0, r1, a0, a1).intersection(bench_clip)
        for h in holes_for(poly):
            poly = poly.difference(h)
        score, eng = scale_marks(poly) if label_scale else ([], [])
        nm = f'{tag}{k + 1}'
        score.append(LineString([]))
        eng += text_polys(nm, *ring_sector(r0, r1, a0, a1).centroid.coords[0], 4.0, rot=(a0 + a1) / 2 - 90) if not label_scale else []
        parts.append(Part(nm, poly, [s for s in score if not s.is_empty], eng,
                          note=f'{solid_note} {a0:.1f}°–{a1:.1f}°'))


# Front layer A: two strips either side of the 5.5 mm slot; scale on the outer strip
band_layer('AI', Ri, Rm - P['slot'] / 2, L1, solid_note='front, inner strip')
band_layer('AO', Rm + P['slot'] / 2, Ro, L1, label_scale=True, solid_note='front, outer strip, scale engraved')
# Middle layer B: two strips either side of the 11 mm channel, joints staggered
band_layer('BI', Ri, Rm - P['chan'] / 2, L2, solid_note='middle, inner strip')
band_layer('BO', Rm + P['chan'] / 2, Ro, L2, solid_note='middle, outer strip')
# Back layer C: solid
band_layer('C', Ri, Ro, L1, solid_note='back, solid')

# ------------------------------------------------------------------ strut (3 layers, staggered joints)
S_len = dl + 40
W = 50.0


def strut_layer(tag, cuts):
    # strut drawn along s (0 = top end, 40 mm above Pa) — local frame: x = s, y across
    edges = [0.0] + cuts + [S_len]
    ang = math.degrees(math.atan2(u[1], u[0]))
    # bench cut: the bottom end is cut parallel to the bench
    for k in range(len(edges) - 1):
        s0, s1 = edges[k], edges[k + 1]
        poly = box(s0, -W / 2, s1, W / 2)
        if k == len(edges) - 2:   # bottom piece: trim to the bench line
            # in the rib frame the bench is y = -H; the strut runs at angle `ang`
            c, sn = math.cos(math.radians(ang)), math.sin(math.radians(ap := ang))
            # bench line in strut coords: y_rib = top_y + s*sn + w*cn = -H, with top = Pa - 40u
            top = (Pa[0] - 40 * u[0], Pa[1] - 40 * u[1])
            # normal of strut across = (-sn, c) in rib frame
            pts = []
            for w in (-W / 2, W / 2):
                yr0 = top[1] + w * c
                s_b = (-P['H'] - yr0) / sn
                pts.append((s_b, w))
            poly = Polygon([(s0, -W / 2), (pts[0][0], -W / 2), (pts[1][0], W / 2), (s0, W / 2)])
        for sb in (40.0, 100.0):
            if s0 + 8 < sb < s1 - 8:
                poly = poly.difference(circle(sb, 0, 5.5))
        nm = f'{tag}{k + 1}'
        parts.append(Part(nm, poly, [], text_polys(nm, (s0 + min(s1, poly.bounds[2])) / 2, 0, 4.0),
                          note=f'strut, {tag[-1]} layer, {s0:.0f}–{s1:.0f} mm from the top end'))


strut_layer('SA', [400.0, 800.0])
strut_layer('SB', [200.0, 600.0, 1000.0])
strut_layer('SC', [400.0, 800.0])

# ------------------------------------------------------------------ carriage + LED holder
car = Polygon([(-45, 1090), (45, 1090), (45, 1226), (5, 1226), (0, 1242), (-5, 1226), (-45, 1226)])
car = affinity.translate(car, 0, 0)
for uu in (-30, 30):
    car = car.difference(circle(uu, Rm, 5.5))
for u0, u1 in ((-30, -10), (10, 30)):
    car = car.difference(box(u0, P['led_r'] - t / 2, u1, P['led_r'] + t / 2))
# local frame for flat cutting: shift so v=0 at bottom
car = affinity.translate(car, 0, -1090)
parts.append(Part('K1', car, [LineString([(0, 1226 - 1090 - 18), (0, 1226 - 1090)])],
                  text_polys('K1', 0, 60, 5), note='carriage plate; pointer reads the altitude scale'))
holder = box(-45, 0, 45, 80)
holder = unary_union([holder, box(-30, -t, -10, 0), box(10, -t, 30, 0)])
holder = holder.difference(circle(0, P['led_z'] - t, 30))
for dx in (-15, 15):
    for dy in (-15, 15):
        holder = holder.difference(circle(dx, P['led_z'] - t + dy, 3.5))
holder = holder.difference(box(-40, 62, -20, 74))   # cable hole
parts.append(Part('K2', holder, [], text_polys('K2', 28, 70, 4),
                  note='LED holder; tabs go into the carriage slots. Ø30 hole + M3 holes on a 30 mm square: drill to suit your LED'))
parts.append(Part('K3', box(0, 0, 40, 14).difference(circle(10, 7, 5.5)).difference(circle(30, 7, 5.5)), [],
                  [], qty=2, note='T-nut plates: sit in the channel under the M5 bolts (optional, instead of bolt heads)'))

# ------------------------------------------------------------------ turntable
# Stack, from the bench: T2 base (6) · lazy susan (8) · T1 disc (6) · top layer (6) = 26 mm.
# The top layer is the T3 centre disc plus the scale ring in two halves (T4A, T4B), glued on T1 with the joints staggered.
# The ring is 470 mm across, so the bearing numbers sit outside the corners of a 250 mm model (177 mm from the centre).
R1 = P['disc'] / 2                 # T1
Rc, Ri_, Ro_ = P['centre'] / 2, P['centre'] / 2, P['ring'] / 2
top = circle(0, 0, P['disc'], n=360).difference(circle(0, 0, 5))
parts.append(Part('T1', top, [LineString([(-15, 0), (15, 0)]), LineString([(0, -15), (0, 15)])],
                  text_polys('T1 · glue T3 and the ring T4 on this face', 0, -40, 6),
                  note='turntable disc; T3 and the scale ring are glued on top of it'))
cen = circle(0, 0, P['centre'], n=360)
m2 = P['model'] / 2
csc = [LineString([(-m2, -m2), (m2, -m2), (m2, m2), (-m2, m2), (-m2, -m2)]),
       LineString([(-15, 0), (15, 0)]), LineString([(0, -15), (0, 15)])]
cen_en = [Polygon([(0, 112), (-9, 90), (9, 90)])] + text_polys('MODEL NORTH', 0, 78, 6)
cen_en += text_polys(f'{P["model"]:.0f} mm model here', 0, -70, 6)
parts.append(Part('T3', cen, csc, cen_en, note=f'centre of the top layer; scored square shows where a {P["model"]:.0f} mm model sits'))
# scale ring: ticks every degree at the outer edge, numbers every 10°, N/E/S/W
rsc, ren = [], []
for b_ in range(360):
    L = 12 if b_ % 10 == 0 else 8 if b_ % 5 == 0 else 4.5
    br = math.radians(b_)
    rsc.append(LineString([(math.sin(br) * (Ro_ - 2 - L), math.cos(br) * (Ro_ - 2 - L)), (math.sin(br) * (Ro_ - 2), math.cos(br) * (Ro_ - 2))]))
    if b_ % 10 == 0:
        ren += text_polys(str(b_), math.sin(br) * (Ro_ - 23), math.cos(br) * (Ro_ - 23), 7, rot=-b_)
for lab, b_ in (('N', 0), ('E', 90), ('S', 180), ('W', 270)):
    br = math.radians(b_); ren += text_polys(lab, math.sin(br) * (Ro_ - 44), math.cos(br) * (Ro_ - 44), 11, rot=-b_)
ring = circle(0, 0, P['ring'], n=720).difference(circle(0, 0, P['centre'], n=360))
SPLIT = 44.5                       # joint between the halves: bearings 44.5° and 224.5°, clear of the numbers
d_ = (math.sin(math.radians(SPLIT)), math.cos(math.radians(SPLIT)))
nrm = (-d_[1], d_[0])              # left of the 44.5° line = the north-west half
big = 1000
halfA = Polygon([(-d_[0] * big, -d_[1] * big), (d_[0] * big, d_[1] * big),
                 (d_[0] * big + nrm[0] * big, d_[1] * big + nrm[1] * big), (-d_[0] * big + nrm[0] * big, -d_[1] * big + nrm[1] * big)])
for nm, hp, rng in (('T4A', halfA, '224.5°–360°–44.5°'), ('T4B', box(-big, -big, big, big).difference(halfA), '44.5°–224.5°')):
    piece = ring.intersection(hp)
    sc_ = [l.intersection(piece) for l in rsc if l.intersects(piece.buffer(-0.3))]
    sc_ = [g for g in sc_ if g.geom_type == 'LineString' and not g.is_empty]
    en_ = [g for g in ren if piece.buffer(-0.5).contains(g)]
    parts.append(Part(nm, piece, sc_, en_, note=f'scale ring half, bearings {rng}; glue on T1 around T3, joints off the T1 edge'))
# base, with a tab on the arc side carrying the index
B = P['base'] / 2
base = box(-B, -B, B, B + P['tab'])
for x in (-B + 15, B - 15):
    for y in (-B + 15, B + P['tab'] - 15):
        base = base.difference(circle(x, y, 6))
idx_y = Ro_ + 2                    # the index tip, just outside the ring
bsc = [LineString([(-25, idx_y + 3), (25, idx_y + 3)]), LineString([(-25, idx_y + 3), (-25, idx_y + 43)]),
       LineString([(25, idx_y + 3), (25, idx_y + 43)])]
ben = text_polys('INDEX · this end faces the arc', 0, B + P['tab'] - 22, 6)
ben += text_polys('Glue T5, T5 and T5T in the scored outline', 0, idx_y + 52, 5)
ben += text_polys('Lazy-susan bearing centred here', 0, 0, 7)
parts.append(Part('T2', base, bsc, ben, note=f'turntable base; the tab carries the index, pointing at the arc'))
ptr = Polygon([(-25, 3), (-6, 3), (0, 0), (6, 3), (25, 3), (25, 43), (-25, 43)])
parts.append(Part('T5', ptr, [], [], qty=2, note='index pointer: glue 2 on the T2 tab, T5T on top; the tip reads the scale ring'))
parts.append(Part('T5T', ptr, [LineString([(0, 0), (0, 30)])], [Polygon([(0, 1), (-5, 10), (5, 10)])],
                  note='index pointer, top layer: engraved line and arrow (goes on top of the two T5)'))

# ------------------------------------------------------------------ feet
fp = box(0, 0, 360, 200)
for x in (15, 345):
    for y in (15, 185):
        fp = fp.difference(circle(x, y, 6))
parts.append(Part('F1', fp, [LineString([(50, 100 - 9), (310, 100 - 9)]), LineString([(50, 100 + 9), (310, 100 + 9)])],
                  text_polys('F1 · rib stands between the lines', 180, 150, 6), note='arc foot plate; clamp to the bench'))
rf = box(0, 0, 200, 150)
for x in (15, 185):
    for y in (15, 135):
        rf = rf.difference(circle(x, y, 6))
parts.append(Part('F2', rf, [LineString([(100 - 9, 30), (100 - 9, 120)]), LineString([(100 + 9, 30), (100 + 9, 120)])],
                  text_polys('F2', 40, 75, 6), note='strut foot plate'))
# spacing gauge: sets the turntable centre 46 mm in front of the rib face
g = box(0, 0, 120, 30).union(box(0, 0, 14, 60))
parts.append(Part('G1', g, [], text_polys(f'{P["led_z"]:.0f} mm', 70, 15, 7),
                  note='offset gauge: rib front face to the beam plane through the turntable centre'))


# ------------------------------------------------------------------ nest onto sheets (shelf packing)
def lay_flat(p):
    """Rotate a part so its longest direction is horizontal, then move to the origin."""
    geo = [p.cut] + p.score + p.engrave
    mrr = p.cut.minimum_rotated_rectangle
    c = list(mrr.exterior.coords)
    e = [(c[i + 1][0] - c[i][0], c[i + 1][1] - c[i][1]) for i in range(2)]
    longest = max(e, key=lambda v: math.hypot(*v))
    ang = -math.degrees(math.atan2(longest[1], longest[0]))
    geo = [affinity.rotate(gg, ang, origin=(0, 0)) for gg in geo]
    minx, miny = geo[0].bounds[0], geo[0].bounds[1]
    geo = [affinity.translate(gg, -minx, -miny) for gg in geo]
    return geo


items = []
for p in parts:
    for q in range(p.qty):
        items.append((p, lay_flat(p)))
items.sort(key=lambda it: -(it[1][0].bounds[2] * it[1][0].bounds[3]))
SW, SH, M, G = *P['sheet'], P['margin'], P['gap']
# guillotine packing: each sheet keeps a list of free rectangles; parts go in the best-fitting one, turned 90° if that fits better
sheets, free = [], []
for p, geo in items:
    best = None
    for rot in (0, 90):
        g2 = geo if rot == 0 else [affinity.rotate(gg, 90, origin=(0, 0)) for gg in geo]
        if rot:
            mx, my = g2[0].bounds[0], g2[0].bounds[1]; g2 = [affinity.translate(gg, -mx, -my) for gg in g2]
        w, h = g2[0].bounds[2], g2[0].bounds[3]
        for si, fr in enumerate(free):
            for fi, (fx, fy, fw, fh) in enumerate(fr):
                if w <= fw + 1e-6 and h <= fh + 1e-6:
                    score = (si, min(fw - w, fh - h))
                    if best is None or score < best[0]:
                        best = (score, si, fi, g2, w, h)
    if best is None:
        w, h = geo[0].bounds[2], geo[0].bounds[3]
        assert w <= SW - 2 * M and h <= SH - 2 * M, f'{p.name} does not fit: {w:.0f}×{h:.0f}'
        sheets.append([]); free.append([(M, M, SW - 2 * M, SH - 2 * M)])
        best = ((len(sheets) - 1, 0), len(sheets) - 1, 0, geo, w, h)
    _, si, fi, g2, w, h = best
    fx, fy, fw, fh = free[si].pop(fi)
    sheets[si].append((p, [affinity.translate(gg, fx, fy) for gg in g2]))
    rw, rh = fw - w - G, fh - h - G
    # split along the longer leftover so the big free piece stays whole
    if rw > rh:
        new = [(fx + w + G, fy, rw, fh), (fx, fy + h + G, w, rh)]
    else:
        new = [(fx, fy + h + G, fw, rh), (fx + w + G, fy, rw, h)]
    free[si] += [r for r in new if r[2] > 10 and r[3] > 10]


def rings(g):
    gs = g.geoms if hasattr(g, 'geoms') else [g]
    for gg in gs:
        if gg.is_empty:
            continue
        yield list(gg.exterior.coords)
        for i in gg.interiors:
            yield list(i.coords)


for n, sh in enumerate(sheets, 1):
    # SVG (y down)
    f = lambda pts: ' '.join(f'{px:.3f},{SH - py:.3f}' for px, py in pts)
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{SW}mm" height="{SH}mm" viewBox="0 0 {SW} {SH}">',
           f'<rect x="0" y="0" width="{SW}" height="{SH}" fill="none" stroke="#999" stroke-width="0.3" stroke-dasharray="4 4"/>']
    doc = ezdxf.new('R2010'); doc.units = ezdxf.units.MM; msp = doc.modelspace()
    for lay, col in (('CUT', 1), ('SCORE', 5), ('ENGRAVE', 7), ('SHEET', 8)):
        doc.layers.add(lay, color=col)
    msp.add_lwpolyline([(0, 0), (SW, 0), (SW, SH), (0, SH)], close=True, dxfattribs={'layer': 'SHEET'})
    for p, geo in sh:
        cut, score, eng = geo[0], geo[1:1 + len(p.score)], geo[1 + len(p.score):]
        for g in eng:
            d_ = ''.join(f'M{f(r)}Z' for r in rings(g))
            out.append(f'<path d="{d_.replace(" ", " L")}" fill="#000" fill-rule="evenodd" stroke="none"/>')
            for r in rings(g):
                msp.add_lwpolyline(r, close=True, dxfattribs={'layer': 'ENGRAVE'})
        for s in score:
            out.append(f'<polyline points="{f(s.coords)}" fill="none" stroke="#0000ff" stroke-width="0.1"/>')
            msp.add_lwpolyline(list(s.coords), dxfattribs={'layer': 'SCORE'})
        for r in rings(cut):
            out.append(f'<polygon points="{f(r)}" fill="none" stroke="#ff0000" stroke-width="0.1"/>')
            msp.add_lwpolyline(r, close=True, dxfattribs={'layer': 'CUT'})
    out.append('</svg>')
    open(f'{OUT}/heliodon_sheet_{n:02d}.svg', 'w').write('\n'.join(out))
    doc.saveas(f'{OUT}/heliodon_sheet_{n:02d}.dxf')

# parts list + key geometry for the drawing
summary = dict(params=P, Rm=Rm, yb=yb, strut=dict(Pa=Pa, Pb=Pb, foot=F, length=S_len),
               L1=L1, L2=L2, sheets=len(sheets),
               parts=[dict(name=p.name, qty=p.qty, note=p.note.strip(),
                           size=[round(lay_flat(p)[0].bounds[2]), round(lay_flat(p)[0].bounds[3])],
                           sheet=next(i for i, s in enumerate(sheets, 1) if any(pp is p for pp, _ in s))) for p in parts])
json.dump(summary, open(f'{OUT}/heliodon_parts.json', 'w'), indent=1)
print(f'{len(parts)} part types, {len(items)} pieces, {len(sheets)} sheets of {SW:.0f}×{SH:.0f} mm')
